delivery_data <- read.table("Exercise - Lab 05.txt", header = TRUE)
names(delivery_data) <- "Delivery_Time"
attach(delivery_data)
delivery_hist <- hist(Delivery_Time, main = "Histogram of Delivery Times", 
                      breaks = seq(20, 70, length = 10), right = FALSE,
                      xlab = "Delivery Time (minutes)", col = "lightcoral")
delivery_freq <- delivery_hist$counts
delivery_cum <- cumsum(delivery_freq)
delivery_new <- c(0, delivery_cum[-length(delivery_cum)])
lot(delivery_breaks, delivery_new, type = "l", 
    main = "Cumulative Frequency Polygon for Delivery Times", 
    xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency", 
    ylim = c(0, max(delivery_cum)), col = "purple", lwd = 2)
points(delivery_breaks, delivery_new, pch = 16, col = "orange")
